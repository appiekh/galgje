<?php



for($i = 10; $i < 1001; $i += 10){
    echo $i . PHP_EOL;
}
?>